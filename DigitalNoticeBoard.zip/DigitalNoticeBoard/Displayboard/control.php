 
<?php
header("Refresh:2");

        include 'dbconnect.php';
    $sql="select value from control";
$result = $conn->query($sql);
                    if ($result->num_rows>0){
                        $row=$result->fetch_assoc();
                    $page=$row['value'];}
              if ($page ==0){
             include"home.php";
         } 
    if ($page ==1){
             include"news.php";
         }
    
    if ($page ==2){
    include"emagazine.php";
    }
    if ($page==3){
        
    include"bus.php";}
if ($page==4){
        
    include"notification.php";}
 if ($page ==5){
             include"firstyear.php";
         }
    
    if ($page ==6){
    include"second.php";
    }
    if ($page==7){
        
    include"third.php";}
if ($page==8){
        
    include"fourth.php";}

    
       ?> 