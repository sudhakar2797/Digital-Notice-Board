      <?php     if (PHP_SESSION_NONE) {session_start();}?>

<?php
if(isset($_POST['send'])){
              
                $subject = " IV Query ";
                $message = "
                <html>
        <body style='width: 800px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 800px; height:100px;'><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'><br>QUERY<br><br><br>
                </div>
                        <pre style=' font-size:20px;font-family:calibre;'>   
    Sender Name                              :     ".$_POST['ccon']." 
    
    Query                                          :     ".$_POST['query']."

    Mail ID                                        :     ".$_POST['cemail']."              </pre>
      
        </body>
</html>";
$cto="sudhakar.it.12345@gmail.com";                
                $from=$_POST['cemail'];
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: '.$from."\r\n".
                            'X-Mailer: PHP/' . phpversion();		
                $result=mail($cto,$subject, $message, $headers); 
                if ($result) {
              $_SESSION['msg']= "Successfully Send";
              header("location:login.php");
                }else{
               $_SESSION['msg']= "Please Try Again";
               header("location:login.php");
                }
    
               }
    
?>