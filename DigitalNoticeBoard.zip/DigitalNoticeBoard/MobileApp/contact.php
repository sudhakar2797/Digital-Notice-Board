      <?php     if (PHP_SESSION_NONE) {session_start();}?>

<!DOCTYPE html>
<html>
  <head>
  
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>IT Events</title>

    <link href="assets/css/bootstrap.css" rel="stylesheet">


    <link href="assets/css/main.css" rel="stylesheet">

    <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
    <script src="assets/js/hover.zoom.js"></script>
    <script src="assets/js/hover.zoom.conf.js"></script>

  </head>

  <body>

    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">INFORMATION TECHNOLOGY</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="home.php">Home</a></li>
            
            <li><a href="rules.php">Rules</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="logout.php">Logout</a></li>
<?php if( $_SESSION['log']=="admin"){?>
            <li><a href="adminpanel.php">Admin</a></li><?php }?>

          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
	<div id="ww">
	    <div class="container">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2 centered">
                                    <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
					</div><!-- /col-lg-8 -->
			</div><!-- /row -->
	    </div> <!-- /container -->
	</div><!-- /ww -->
	
	
	<!-- +++++ Contact Section +++++ -->
	
	<div class="container pt">
		<div class="row mt">
			<div class="col-lg-6 col-lg-offset-3 centered">
				<h3>CONTACT US</h3>
				<hr>
				<p>If You Have Any Difficulty Please Contact Our Department Events Coordinator</p>
			</div>
		</div>
		<div class="row mt">	
			<div class="col-lg-8 col-lg-offset-2">
                            <form role="form" action="checkcontactus.php" method="post">
				  <div class="form-group">
				    <input type="name" class="form-control"  name="ccon" id="NameInputEmail1" placeholder="Your Name">
				    <br>
				  </div>
				  <div class="form-group">
				    <input type="email" class="form-control" name="cemail" id="exampleInputEmail1" placeholder="Enter email">
				    <br>
				  </div>
				  
                                    <textarea class="form-control" rows="6" name="query" placeholder="Enter your text here"></textarea>
				    <br>
				  <button type="submit" name="send" class="btn btn-success">SUBMIT</button>
				</form>    			
			</div>
		</div><!-- /row -->
	</div><!-- /container -->
	
	
	<!-- +++++ Footer Section +++++ -->
	
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<h4>KCET</h4>
					<p>
						S.P.G.Chidambara Nadar - C.Nagammal Campus,<br/>
						Post Box No.12  <br/>
						Virudhunagar -626 001
					</p>
				</div><!-- /col-lg-4 -->
				<div class="col-lg-4">
					<h4>Contact</h4>
					<p>
			Web-site: <a href="www.kamarajengg.edu.in" style="color: crimson">www.kamarajengg.edu.in</a> <br> 
                        Phone:04549 278171<br> 
					</p>
				</div><!-- /col-lg-4 -->
			<div class="col-lg-4">
					<h4>Happy Events</h4>
					<p>
                                            <img src="assets/img/clients.png" width="200px" height="200px" >
					</p>
				</div><!-- /col-lg-4 -->
			</div>
		</div>
	</div>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
