<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Digital Notice Board</title>

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets1/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets1/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets1/css/form-elements.css">
        <link rel="stylesheet" href="assets1/css/style.css">

    </head>

    <body>

        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1><strong>Digital</strong>Notice Board</h1>
                            <div class="description">
    		<p>
				Department of Information Technology 
				Welcomes You To <a href="http://www.kamarajengg.edu.in"><strong> KCET</strong></a>
                </p>
    	
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>View Latest Updates</h3>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-key"></i>
                        		</div>
                            </div>
                            <div class="form-bottom">
			                     <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        	<div class="social-login-buttons">
                                  <center>  <a class="btn btn-link-1 btn-link-1-facebook" href="?link=1" name="link1" style="width:150px;">
	                        		Latest News
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="?link=2" name="link2" style="width:150px;">
	                        		 E-Magazine
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="?link=3" name="link3" style="width:150px;">
	                        		 Bus Details
	                        	</a>
                                    <a class="btn btn-link-1 btn-link-1-google-plus" href="?link=4" name="link4" style="width:150px;background-color: #357ae8">
	                        		 Notifications
	                        	</a>
                                       <a class="btn btn-link-1 btn-link-1-facebook" href="?link=5" name="link5" style="width:150px;">
	                        		First Year
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="?link=6" name="link6" style="width:150px;">
	                        		 Second Year
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="?link=7" name="link7" style="width:150px;">
	                        		 Third Year
	                        	</a>
                                    <a class="btn btn-link-1 btn-link-1-google-plus" href="?link=8" name="link8" style="width:150px;background-color: #357ae8">
	                        		 Final Year
	                        	</a>
                                      
                                    <a  href="home.php">
                                        <button type="submit" class="btn">Back</button>
                                    </a></center>
                        	</div>
                        </div>
                    </div>
                                <?php
        require 'dbconnect.php';
    if(isset($_GET['link'])){
    $link=$_GET['link'];
    if ($link == '1'){
      $sql="UPDATE control SET value='$link'";
                 
    mysqli_query($conn,$sql);
                             
    }
    if ($link == '2'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    if ($link == '3'){
        $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
     
    }
    if ($link == '4'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    if ($link == '5'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    if ($link == '6'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    if ($link == '7'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    if ($link == '8'){
      $sql="UPDATE control SET value='$link'";
                 
     mysqli_query($conn,$sql);
    
    }
    }  ?>  
 
                                
                                
                                
                                
		                    </div>
                        </div>
                    </div>
                   
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="assets1/js/jquery-1.11.1.min.js"></script>
        <script src="assets1/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets1/js/jquery.backstretch.min.js"></script>
        <script src="assets1/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>