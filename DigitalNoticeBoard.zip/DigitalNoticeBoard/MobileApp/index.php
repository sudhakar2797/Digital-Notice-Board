 
                   
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Digital Board</title>

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="choose-layout-assets/style.css">


    </head>
<?php if(isset($_POST['check'])){?>
     <link href="assets/css/alert.css" rel="stylesheet">
     <center>   <div class="alert info" style="width: 200px">
                                        <span class="closebtn">&times;</span>  
                                        <p>Please Login</p>
                                         </div></center>
                         <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
    <body>
    
    	<div class="top">
    		<h1>Digital Notice Board</h1>
    		<p>
				Department of Information Technology 
				Welcomes You To <a href="Http://www.kamarajengg.edu.in"><strong> KCET</strong></a></p>
        </div>
    	<div class="section-container">
	        <div class="container layouts">
	            <div class="row">
	                <div class="col-sm-12 section-description">
	                    <h3>Start Journey</h3>
	                </div>
	            </div>
	            <div class="row">
	            	<div class="col-sm-10 col-sm-offset-1">
	            		<div class="row">
		                <div class="col-sm-4 layout-box">
                                    <a href="login.php">
                                        <img src="choose-layout-assets/1.jpg" width="200px" height="200px" alt="">
			                	</a>
			                	<p>Login</p>
		                    </div>	
                                    <div class="col-sm-4 layout-box">
                                       <form action="index.php" method="post"> <a href="#">
                                                <button name="check" style="border: none"><img src="choose-layout-assets/2.jpg" width="200px" height="200px" alt="">
                                                </button></a></form>
			                	<p>Home</p>
		                    </div>
		                    <div class="col-sm-4 layout-box">
                                        <form action="index.php" method="post"> <a href="#">
                                                <button name="check" style="border: none"><img src="choose-layout-assets/3.jpg" width="200px" height="200px" alt="">
                                                </button></a></form>
			                    <p>Contact Admin</p>
		                    </div>
		                    
	                    </div>
                    </div>
	            </div>
	        </div>
        </div>
        
        <div class="container footer">
            <div class="row">
                <div class="col-sm-12">
                	 
                        <?php
echo "<p><center> &copy; "  . " Kamaraj  of College Engineering & Technology</center></p>";?>
<a href="http://www.kamarajengg.edu.in" target="_blank">KCET</a>.</p>
                </div>
            </div>
        </div>
        
    </body>

</html>