<?php
session_start();
    if(session_destroy())
    {
         require 'dbconnect.php';
    
      $sql="UPDATE control SET value='0'";
                 
    if(mysqli_query($conn,$sql)){
                             
    
    header("location:index.php");}
    }
?>