

<?php

if(isset($_POST['submit'])){
                            if (empty($_POST['name'])) {
                       $error= "Name Is Required";
    
                }elseif (empty($_POST['email'])) {
               $error= "Email Is Required";
            
               }elseif((!empty ($_POST['email']))&& (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))) {
                $error= "Invalid Email Format"; 
                  
                   }elseif (empty($_POST['query'])) {
               $error= "Query Is Required";
            
             
               }else{
    
                $subject = "Digital Notice Board Query ";
                $message = "
                <html>
        <body style='width: 500px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 500px; height:100px;'><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'><br>QUERY<br><br><br>
                </div>
                        <pre style=' font-size:20px;font-family:calibre;'>   
    Sender Name                              :     ".$_POST['name']." 
    
    Query                                          :     ".$_POST['query']."
                        </pre>
      
        </body>
</html>";
                $from=$_POST['email'];
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: '.$from."\r\n".
                            'X-Mailer: PHP/' . phpversion();
                $to="Sudhakar.it.12345@gmail.com";
                $result=mail($to,$subject, $message, $headers); 
                if ($result) {
              $error= "Successfully Send";
                }else{
               $error= "Please Try Again";
                }
    
               }
    
}
?>




<html><style>.card{

                                             box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                         width:1000px;
                     height: 1000px;
                        
        }</style><body><center><div class="card">
<?php include 'header.php';?>
        <br><h1 class="card" style="width:500px;height: 150px;border-radius: 50px;font-size: 25px;color:#357ae8">Digital Notice Board Admin Panel<br>            
            <img src="images/contact1.jpg" width="80px" height="80px">
            <img src="images/contact2.jpg" width="200px" height="100px">                          
<img src="images/contact1.jpg" width="80px" height="80px"></h1>
        <link rel="stylesheet" href="css/common.css">

        <?php if(!empty($error)){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert success" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $error;?>
                                     </div>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
             <div class="container">

  <form id="contact" action="contact.php" method="post"> 
      <img src="images/contact.jpg" width="100px" height="100px">                  
<br>
                 
      <input placeholder="Your name" type="text"  name="name" required ><br><br>
   
   
      <input placeholder="Your Email Address" type="email" name="email"  required><br><br>
   
   
      <textarea placeholder="Type your message here...." name="query"  required></textarea><br><br>
   
   
      <button name="submit" type="submit" class="but"><span>Send</span></button>
   
  </form>
             </div>
      
    <br><br><br><?php include 'footer.php';?></div></div></center>

    
    
    
    
    
    
    
</body></html>