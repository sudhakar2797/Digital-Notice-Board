
<?php 
        if (PHP_SESSION_NONE) {session_start();}?>
	
<?php
if(isset($_POST['submit'])){
/*** check if a file was submitted ***/
    error_reporting(E_ERROR | E_PARSE);

if(!isset($_FILES['userfile']))
    {
    $msg="Please select a file";
    }
else
    {
    try {
        upload();
        /*** give praise and thanks to the php gods ***/
        $msg="Thank you for submitting";
        }
    catch(PDOException $e)
        {
    echo '<h4>'.$e->getMessage().'</h4>';
        }
    catch(Exception $e)
        {
        echo '<h4>'.$e->getMessage().'</h4>';
        }
    }

}
/**
 *
 * the upload function
 * 
 * @access public
 *
 * @return void
 *
 */
function upload(){
/*** check if a file was uploaded ***/
if(is_uploaded_file($_FILES['userfile']['tmp_name']) && getimagesize($_FILES['userfile']['tmp_name']) != false)
    {
     /***  get the image info. ***/
    $size = getimagesize($_FILES['userfile']['tmp_name']);

    /*** assign our variables ***/
    $image_type   = $size['mime'];
    $imgfp        = fopen($_FILES['userfile']['tmp_name'], 'rb');
    $image_width  = $size[0];
    $image_height = $size[1];
    $image_size   = $size[3];
    $image_name   = $_FILES['userfile']['name'];
    $maxsize      = 99999999;

    /***  check the file is less than the maximum file size ***/
    if($_FILES['userfile']['size'] < $maxsize )
        {
        /*** create a second variable for the thumbnail ***/
        $thumb_data = $_FILES['userfile']['tmp_name'];

        /*** get the aspect ratio (height / width) ***/
        $aspectRatio=(float)($size[0] / $size[1]);

        /*** the height of the thumbnail ***/
        $thumb_height = 100;

        /*** the thumb width is the thumb height/aspectratio ***/
        $thumb_width = $thumb_height * $aspectRatio;

        /***  get the image source ***/
        $src = ImageCreateFromjpeg($thumb_data);
        
        /*** create the destination image ***/
        $destImage = ImageCreateTrueColor($thumb_width, $thumb_height);

        /*** copy and resize the src image to the dest image ***/
        ImageCopyResampled($destImage, $src, 0,0,0,0, $thumb_width, $thumb_height, $size[0], $size[1]);

        /*** start output buffering ***/
        ob_start();

        /***  export the image ***/
        imageJPEG($destImage);

        /*** stick the image content in a variable ***/
        $image_thumb = ob_get_contents();

        /*** clean up a little ***/
        ob_end_clean();

        /*** connect to db ***/
        $dbh = new PDO("mysql:host=localhost;dbname=digitalnoticeboard", 'root', '');

        /*** set the error mode ***/
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $dateofadd=date('Y-m-d');
        $personupdate=$_POST['name'];
        $personid=$_SESSION['log'];
        $comment=$_POST['comment'];
        $yearid=$_POST['year'];
        /*** prepare the sql ***/
        $stmt = $dbh->prepare("INSERT INTO testblob (image_type ,image, dateofadd, personupdate, image_thumb, personid, comments, image_name,yearid)
        VALUES (? ,?, ?, ?, ?, ?, ?,?,?)");
        $stmt->bindParam(1, $image_type);
        $stmt->bindParam(2, $imgfp, PDO::PARAM_LOB);
        $stmt->bindParam(3, $dateofadd, PDO::PARAM_STR);
        $stmt->bindParam(4, $personupdate,  PDO::PARAM_STR);
        $stmt->bindParam(5, $image_thumb,  PDO::PARAM_LOB);
        $stmt->bindParam(6, $personid, PDO::PARAM_STR);
        $stmt->bindParam(7, $comment,  PDO::PARAM_STR);
        $stmt->bindParam(8, $image_name);
        $stmt->bindParam(9, $yearid,PDO::PARAM_INT);

        /*** execute the query ***/
        $stmt->execute();
        }
    else
        {
    /*** throw an exception is image is not of type ***/
    throw new Exception("File Size Error");
        }
    }
else
    {
    // if the file is not less than the maximum allowed, print an error
    throw new Exception("Unsupported Image Format!");
    }
}
?>


<html><body><center><div class="card">
            <br><style>
               .clickMe {
  background: #000;
  /* IE Fallback */
 border: none;
  padding: 5px 0px;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  color: #fff;
  font-size: 10px;
  text-transform: uppercase;
  font-weight: 800;
}   
            </style>
        <?php include 'header.php';?>
        <br><h1 class="card" style="width:500px;height: 90px;border-radius: 50px;font-size: 25px;color: #357ae8"><br>Digital Notice Board Admin Panel</h1>
      <link rel="stylesheet" href="css/style.css">
                                        <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo "If Your Notice Not In Image Format Please Use Panel Services"?>
                                        <a href="service.php"><button class="clickMe">Click Me</button></a>
                                     </div>
                 
       <?php if(!empty($msg)){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $msg;?>
                                     </div><?php }?>
                         <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>

        <style>
            .card{

                                             box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                         width:1000px;
                     height: 1000px;
                        
        }
           
 #yourBtn{
                font-family: calibri;
                width: 160px;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                text-align: center;
                 background-color: #357ae8;
                 color: white;
                 padding: 14px 20px;
                 margin: 8px 0;
                 border: none;
                 cursor: pointer;
               }
               
               
               #yourBtn:hover{
                
                 background-color: #0000FF;
                 
               }
button::-moz-focus-inner {
  border: 0;
}
input[type=submit]::-moz-focus-inner {
  border: 0;
}
input[type=file]::-moz-focus-inner {
  border: 0;
}




input[type=submit]{
    background-color: forestgreen;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    border-radius: 30px;
}

input[type=submit]:hover{
    background-color: green;
    
}

.lg-container,.card1{
	width:275px;
	margin:100px auto;
	padding:20px 40px;
	border:1px solid #f4f4f4;
	background:rgba(255,255,255,.5);
	-webkit-border-radius:10px;
	-moz-border-radius:10px;
	border-radius:10px;
	
	-webkit-box-shadow: 0 0 2px #aaa;
	-moz-box-shadow: 0 0 2px #aaa;
	box-shadow: 0 0 2px #aaa;
}

input[type=text]{
    width: 200px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.2s ease-in-out;
}

input[type=text]:focus{
    width: 80%;
    border: 2px solid #3498DB;
box-shadow: none;
}

input[type=text]:hover {
    width: 90%;
}
select {
    width: 200px;
    height:50px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}


option {
    height:50px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}


</style>

                                            <div class="lg-container" style="background-image:url(images/bg.jpg);">
                                                <center><h2 style="color:#fff;font-family:calibri;">Insert New Updates</h2>
                <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
                    <link rel="stylesheet" href="css/update.css" />
                    
                    
                    <label><select name="year" required>
                                                <option value="">Select</option>
                                                <option value="1">Common</option>
                                                <option value="2">E-magazine</option>
                                                <option value="3" >Bus Details</option>
                                                <option value="4" >Notification</option>
                                                <option value="5">First Year</option>
                                                <option value="6">Second Year</option>
                                                <option value="7" >Third Year</option>
                                                <option value="8" >Final Year</option>
                                            </select>
                                    </label><br><br>
                        <input type="text" name="comment" id="username" placeholder="Update Remark " required/><br>
			 <div id="yourBtn" onclick="getFile()">Click To Insert A Data</div>
                                                <div style='height: 0px;width: 0px; overflow:hidden;'>
                                                <input id="upfile" type="file" name="userfile"  size="40" onchange="sub(this)" required>
                                                <input type="hidden" name="MAX_FILE_SIZE" value="10000000">
                                                </div>
                         <input type="text" name="name" id="username" placeholder="Your Name " required/><br><br>
                         
                         <input  type="submit" name="submit" value="Insert" />
                </form> </center> 
                                            
                                              

                                            </div><br> <?php include 'footer.php';?></div></center>
<script type="text/javascript">
 function getFile(){
   document.getElementById("upfile").click();
 }
 function sub(obj){
    var file = obj.value;
    var fileName = file.split("\\");
    document.getElementById("yourBtn").innerHTML = fileName[fileName.length-1];
    document.myForm.submit();
    event.preventDefault();
  }
</script></html>


      
      
      

    
    
    
    
    
    
    
</body></html>
<br><br><br><br><center>
<?php
require 'dbconnect.php';
for($i=1;$i<=8;$i++){
$sql = "SELECT * FROM testblob  where yearid='$i'";
$sth = $conn->query($sql);
while($result=mysqli_fetch_array($sth)){
echo '<img class="img-responsive" src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>';
}}
?>
</center>