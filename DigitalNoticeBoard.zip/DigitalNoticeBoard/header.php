<html><center><br>
        <img src="images/logo.png" width="600px" height="80px"><br></center>

    <a href="welcome.php"><img src="images/home.jpg" style="width: 100px;height: 80px;float: left;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border-bottom-right-radius: 50px;;border-top-right-radius: 50px;"></a>

</html>