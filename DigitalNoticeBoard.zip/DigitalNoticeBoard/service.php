




<html><style>.card{

                                             box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                         width:1000px;
                     height: 1000px;
                        
        }
        a,h1{
            
            text-decoration: none;
        }</style><body><center><div class="card">
<?php include 'header.php';?>
            <br><h1 class="card" style="width:500px;height: 150px;border-radius:50px;color:#357ae8;font-size: 25px;"><br>Digital Notice Board Admin Panel<br>                                      <img src="images/service.jpg" width="80px" height="80px">                  
</h1>
        <link rel="stylesheet" href="css/common.css">

        <?php if(!empty($error)){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert success" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $error;?>
                                     </div>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
             
        
        
<div class="card" style="width: 400px;height: 400px;position: absolute;top:350px;left:250px">
        
        
    <br> <p style="color:crimson;font-family: calibri;font-size: 22px"><b style="color:black">Pdf </b>To <b style="color:black">Image</b> Conversion Use The Following Icons </p>       

<a href="https://www.freepdfconvert.com/pdf-jpg">
<h1 style="color: #357ae8;font-family: calibri;font-size: 22px;">1.<img src="images/pdf.jpg" width="80px" height="80px"><img src="images/to.jpg" width="80px" height="80px"><img src="images/image.jpg" width="80px" height="100px"></h1>
</a>
<br>

<a href="http://image.online-convert.com/convert-to-jpg">
<h1 style="color: #357ae8;font-family: calibri;font-size: 22px;">2.<img src="images/pdf.jpg" width="80px" height="80px"><img src="images/to.jpg" width="80px" height="80px"><img src="images/image.jpg" width="80px" height="100px"></h1>
</a>
</div>
        
        
               
<div class="card" style="width: 400px;height: 400px;position: absolute;top:350px;left:700px">
        
        
    <br> <p style="color:crimson;font-family: calibri;font-size: 22px"><b style="color:black">Word </b>To <b style="color:black">Image </b>Conversion Use The Following Icons </p>       

<a href="https://www.freepdfconvert.com/pdf-jpg">
    <h1 style="color: #357ae8;font-family: calibri;font-size: 22px;">1.<img src="images/word.jpg" width="80px" height="80px"><img src="images/to.jpg" width="80px" height="80px"><img src="images/image.jpg" width="80px" height="100px"></h1>
</a>
<br>

<a href="http://image.online-convert.com/convert-to-jpg">
    <h1 style="color: #357ae8;font-family: calibri;font-size: 22px;">2.<img src="images/word.jpg" width="80px" height="80px"><img src="images/to.jpg" width="80px" height="80px"><img src="images/image.jpg" width="80px" height="100px"></h1>
</a>
</div>
        
        
        
        
       
      <br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><?php include 'footer.php';?></div></center>

    
    
    
    
    
    
    
</body></html>