<?Php
if (isset($_POST['b1'])) {
    header("location:/board/control.php");
}
?>
<?Php
if (isset($_POST['b2'])) {
    header("location:/");
}
?>
<?Php
if (isset($_POST['b3'])) {
    header("location:index.php");
}
?>
<html><body><center><div class="card">
            <br>

            <style>
                .card{

                    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                    width:1000px;
                    height: 1000px;

                }

                button::-moz-focus-inner {
                    border: 0;
                }
                input[type=submit]::-moz-focus-inner {
                    border: 0;
                }
                input[type=file]::-moz-focus-inner {
                    border: 0;
                }




                button{
                    background-color: forestgreen;
                    color: white;
                    padding: 14px 20px;
                    margin: 8px 0;
                    border: none;
                    cursor: pointer;
                    border-radius: 30px;
                }

                button:hover{
                    background-color: green;

                }

                .lg-container,.card1{
                    width:275px;
                    margin:100px auto;
                    padding:20px 40px;
                    border:1px solid #f4f4f4;
                    background:rgba(255,255,255,.5);
                    -webkit-border-radius:10px;
                    -moz-border-radius:10px;
                    border-radius:10px;

                    -webkit-box-shadow: 0 0 2px #aaa;
                    -moz-box-shadow: 0 0 2px #aaa;
                    box-shadow: 0 0 2px #aaa;
                }

            </style>
            <?php include 'header.php'; ?>
            <div class="lg-container" style="background-image:url(images/bg.jpg);">
                <center><h2 style="color:#fff;font-family:calibri;">Select</h2>
                    <a href="MobileApp/index.php"> <button >Mobile App</button>
                    </a><br><a href="Displayboard/control.php">  <button >Display</button>
                    </a><br><a href="index.php">
                        <button >Admin Panel</button>
                    </a></center> 
            </div><br> <?php include 'footer.php'; ?></div></center>
</html>

</body></html>