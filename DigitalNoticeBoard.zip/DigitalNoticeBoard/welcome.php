<!DOCTYPE html>
<head>
	<title>Digital Notice Board Admin Panel</title>
	<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/templatemo_style.css" rel="stylesheet">

	<script src="js/jquery-1.11.1.min.js"></script> 
	<script src="js/templatemo_custom.js"></script>
</head><center><div class="card">
<body ><center><br>
        <img src="images/logo.png" width="600px" height="80px"><br></center>

	<div class="container"><br><br><br>
		<div class="menu">
			<div class="hexagon_container" id="logo">
				<div class="hexagon hexagon2">
                                    	<a href="wel.php">
					<div class="hexagon-in1">
						<div class="hexagon-in2 active">
                                                    <h2>Home</h2>             	 	
						</div>
                                        </div></a>
				</div>					
			</div>
			<div class="hexagon_container" id="team">
				<div class="hexagon hexagon2">
					<div class="hexagon-in1">
						<a href="logout.php">
							<div class="hexagon-in2">
								<i class="fa fa-user"></i>
								<h2>LOGOUT</h2>             	 	
							</div>
						</a>
					</div>
				</div>				
			</div>
			<div class="hexagon_container" id="services">
				<div class="hexagon hexagon2">
					<div class="hexagon-in1">
						<a href="service.php">
							<div class="hexagon-in2">
								<i class="fa fa-cogs"></i>
								<h2>SERVICES</h2>             	 	
							</div>
						</a>
					</div>
				</div>
			</div>		
			<div class="hexagon_container" id="contact">
				<div class="hexagon hexagon2">
					<div class="hexagon-in1">
						<a href="contact.php">
							<div class="hexagon-in2">
								<i class="fa fa-envelope"></i>
								<h2>CONTACT</h2>         	 	
							</div>
						</a>
					</div>
				</div>						
			</div>
                    
		</div>
		<div id="gallery-content">
			<header>
				<h1>Digital Notice Board Admin Panel</h1>
			</header>
			<div class="content gallery" id="page1">
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/4.jpg);border-left:100px ">
                                                                <h3>First Year</h3>
                                                        </div></a>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/2.jpg);">
						<br>  <h3>Second Year</h3>
	         	 	
                                                        </div></a>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/1.jpg);">
						<br> <h3>Third Year</h3>

                                                        </div></a>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/3.jpg);">
							 <h3>Final Year</h3>

                                                        </div></a>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/5.jpg);">
							<h3>Placement</h3>

							</div>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
							<a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/6.jpg);">
						 <h3>General</h3>
	
                                                            </div></a>
						</div>
					</div>
				</div>
				<div class="hexagon_container">
					<div class="hexagon hexagon2 gallery-item">
						<div class="hexagon-in1">
                                                    <a href="first.php"><div class="hexagon-in2" style="background-image:url(images/gallery/7.jpg);">
						<h3>Important</h3>
	
                                                        </div></a>
						</div>
					</div>
                                </div>
				</div>
				</div>
			</div>
			
	
        
</body><br><br></div></center>
</html>